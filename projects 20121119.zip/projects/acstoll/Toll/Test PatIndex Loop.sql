DECLARE @rulename varchar(500), @assetid varchar(100), @reason varchar(2000)
Select @assetid = 'B111', @reason = 'Svc Req:BROKEN', @rulename = '[VECTOR INTERFACE]'

DECLARE @probId varchar(25)
select @probId = null		--  'BROKEN'
select CHARINDEX('[VECTOR INTERFACE]',@RuleName)

IF @RuleName Is Not Null
	BEGIN
		IF CHARINDEX('[VECTOR INTERFACE]',@RuleName) > 0
		BEGIN
			
			
			-- Convert AssetID to adhere to Vector Interface Requirements
			DECLARE @array varchar(4000)
			DECLARE @separator_position int
			DECLARE @array_value varchar(4000)
			DECLARE @separator char(1) 
			DECLARE @counter int
			
			SET @counter = 0
			SET @array = REPLACE(@assetid,'_',',')
			SET @separator = ','
			SET @array = @array + @separator

			--PRINT @array
			WHILE PATINDEX('%' + @separator + '%' , @array) <> 0 
			BEGIN
				  SET @counter = @counter + 1
				  SELECT @separator_position =  PATINDEX('%' + @separator + '%' , @array)
				  SELECT @array_value = left(@array, @separator_position - 1)
				  --PRINT RTRIM(LTRIM(@array_value))
				  IF @Counter = 4
				  BEGIN
					SET @AssetID = RTRIM(LTRIM(@array_value))
					BREAK
				  END			  			  
				  SELECT @array = STUFF(@array, 1, @separator_position, '')			  
			END		
			
			-- Convert Body to adhere to Vector Interface Requirements

			SET @counter = 0
			SET @array = REPLACE(@reason,CHAR(13)+CHAR(10),':')
			--INSERT INTO Debug (DebugOut1) SELECT @array
			SET @separator = ':'
			SET @array = @array + @separator

			DECLARE @ProblemPK int
			DECLARE @ProblemID varchar(25)
			DECLARE @ProblemName varchar(50)
			DECLARE @InterfaceEquipID varchar(25)
			DECLARE @Priority varchar(25)
			DECLARE @PriorityDesc varchar(50)
			DECLARE @DepartmentPK2 varchar(25)
			DECLARE @DepartmentID2 varchar(25)
			DECLARE @DepartmentName2 varchar(25)
			DECLARE @UDFChar5 varchar(50)

			SET @ProblemPK = Null
			SET @ProblemID = Null
			SET @ProblemName = Null
			SET @InterfaceEquipID = Null
			SET @Priority = Null
			SET @PriorityDesc = Null
			SET @DepartmentPK2 = Null
			SET @DepartmentID2 = Null
			SET @DepartmentName2 = Null
			SET @UDFChar5 = Null

			--PRINT @array				
			WHILE PATINDEX('%' + @separator + '%' , @array) <> 0 
			BEGIN
				  --PRINT RTRIM(LTRIM(@array_value))
				  SET @counter = @counter + 1
				  SELECT @separator_position =  PATINDEX('%' + @separator + '%' , @array)
				  SELECT @array_value = left(@array, @separator_position - 1)
				  IF @Counter = 2
					SET @ProblemID = RTRIM(LTRIM(@array_value))
				  IF @Counter = 4
					SET @InterfaceEquipID = RTRIM(LTRIM(@array_value))
				  IF @Counter = 6
					SET @Reason = RTRIM(LTRIM(@array_value))
				  IF @Counter = 8
					SET @Priority = RTRIM(LTRIM(@array_value))
				  IF @Counter = 10
					SET @DepartmentID2 = RTRIM(LTRIM(@array_value))
				  SELECT @array = STUFF(@array, 1, @separator_position, '')			  
			END	
		END
	END
	
	select @assetid, @reason, @ProblemID