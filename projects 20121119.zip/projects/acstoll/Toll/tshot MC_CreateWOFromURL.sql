--USE [entACSTEST]
--GO
/****** Object:  StoredProcedure [dbo].[MC_CreateWOFromURL]    Script Date: 04/17/2012 13:45:40 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
ALTER Procedure [dbo].[MC_CreateWOFromURL]
(
	@Reason varchar(2000) = "Service Request from Email",
	@RequesterName varchar(50) = Null,
	@RequesterEmail varchar(50),
	@AssetPK int = Null,
	@AssetID varchar(100) = Null,
	@ProcedurePK int = Null,
	@WOPK int = Null output,
	@RepairCenterPK int = Null output,
	@RuleName varchar(500) = Null,
	@response int = 0 output
)
As
SET NOCOUNT ON

	DECLARE @Subject As Varchar(100)
	DECLARE @CloseWO As bit

	SET @Subject = RTRIM(IsNull(@AssetID,''))
	SET @CloseWO = 0

	DECLARE @HoldCategoryPK int
	DECLARE @HoldCategoryID varchar(25)
	DECLARE @HoldCategoryName varchar(50)
	DECLARE @DuplicateWO int
	SET @DuplicateWO =  0
	
	

	---------------------------------------------------------------------------------------------------
	-- CUSTOM INTERFACES
	---------------------------------------------------------------------------------------------------

	DECLARE @IsVectorInterface As int
	SET @IsVectorInterface = 0

	IF @RuleName Is Not Null
	BEGIN
		IF CHARINDEX('[VECTOR INTERFACE]',@RuleName) > 0
		BEGIN
			SET @IsVectorInterface = 1
			
			-- Convert AssetID to adhere to Vector Interface Requirements
			DECLARE @array varchar(4000)
			DECLARE @separator_position int
			DECLARE @array_value varchar(4000)
			DECLARE @separator char(1) 
			DECLARE @counter int
			
			SET @counter = 0
			SET @array = REPLACE(@assetid,'_',',')
			SET @separator = ','
			SET @array = @array + @separator

			--PRINT @array
			WHILE PATINDEX('%' + @separator + '%' , @array) <> 0 
			BEGIN
				  SET @counter = @counter + 1
				  SELECT @separator_position =  PATINDEX('%' + @separator + '%' , @array)
				  SELECT @array_value = left(@array, @separator_position - 1)
				  --PRINT RTRIM(LTRIM(@array_value))
				  IF @Counter = 4
				  BEGIN
					SET @AssetID = RTRIM(LTRIM(@array_value))
					BREAK
				  END			  			  
				  SELECT @array = STUFF(@array, 1, @separator_position, '')			  
			END		
			
			-- Convert Body to adhere to Vector Interface Requirements

			SET @counter = 0
			SET @array = REPLACE(@reason,CHAR(13)+CHAR(10),':')
			--INSERT INTO Debug (DebugOut1) SELECT @array
			SET @separator = ':'
			SET @array = @array + @separator

			DECLARE @ProblemPK int
			DECLARE @ProblemID varchar(25)
			DECLARE @ProblemName varchar(50)
			DECLARE @InterfaceEquipID varchar(25)
			DECLARE @Priority varchar(25)
			DECLARE @PriorityDesc varchar(50)
			DECLARE @DepartmentPK2 varchar(25)
			DECLARE @DepartmentID2 varchar(25)
			DECLARE @DepartmentName2 varchar(25)
			DECLARE @UDFChar5 varchar(50)

			SET @ProblemPK = Null
			SET @ProblemID = Null
			SET @ProblemName = Null
			SET @InterfaceEquipID = Null
			SET @Priority = Null
			SET @PriorityDesc = Null
			SET @DepartmentPK2 = Null
			SET @DepartmentID2 = Null
			SET @DepartmentName2 = Null
			SET @UDFChar5 = Null

			--PRINT @array				
			WHILE PATINDEX('%' + @separator + '%' , @array) <> 0 
			BEGIN
				  --PRINT RTRIM(LTRIM(@array_value))
				  SET @counter = @counter + 1
				  SELECT @separator_position =  PATINDEX('%' + @separator + '%' , @array)
				  SELECT @array_value = left(@array, @separator_position - 1)
				  IF @Counter = 2
					SET @ProblemID = RTRIM(LTRIM(@array_value))
				  IF @Counter = 4
					SET @InterfaceEquipID = RTRIM(LTRIM(@array_value))
				  IF @Counter = 6
					SET @Reason = RTRIM(LTRIM(@array_value))
				  IF @Counter = 8
					SET @Priority = RTRIM(LTRIM(@array_value))
				  IF @Counter = 10
					SET @DepartmentID2 = RTRIM(LTRIM(@array_value))
				  SELECT @array = STUFF(@array, 1, @separator_position, '')			  
			END	

			IF NOT @InterfaceEquipID Is Null
			BEGIN
				SET @UDFChar5 = @InterfaceEquipID

				SELECT @HoldCategoryPK = CategoryPK,
					   @HoldCategoryID = CategoryID, 
					   @HoldCategoryName = CategoryName
				FROM Category
				WHERE CategoryID = @InterfaceEquipID	
				
			END

			IF @Priority = '1' or @Priority = '01'
			BEGIN
				SET @CloseWO = 0			
			END
			ELSE
			BEGIN
				SET @CloseWO = 1		
			END
					
			IF NOT @ProblemID Is Null
			BEGIN
				IF EXISTS (SELECT FailurePK FROM Failure WHERE FailureID = @ProblemID)
				BEGIN
					SELECT @ProblemPK = FailurePK,
						   @ProblemName = FailureName
					FROM Failure
					WHERE FailureID = @ProblemID
				END			
				ELSE
				BEGIN
					SET @ProblemID = Null
				END
			END			

			IF NOT @DepartmentID2 Is Null
			BEGIN
				IF EXISTS (SELECT DepartmentPK FROM Department WHERE DepartmentID = @DepartmentID2)
				BEGIN
					SELECT @DepartmentPK2 = DepartmentPK,
						   @DepartmentName2 = DepartmentName
					FROM Department
					WHERE DepartmentID = @DepartmentID2
				END			
				ELSE
				BEGIN
					SET @DepartmentID2 = Null
				END
			END			

			IF NOT @Priority Is Null
			BEGIN
				IF EXISTS (SELECT CodeDesc FROM LookupTableValues WHERE CodeName = @Priority)
				BEGIN
					SELECT @PriorityDesc = CodeDesc
					FROM LookupTableValues
					WHERE CodeName = @Priority
				END			
				ELSE
				BEGIN
					SET @Priority = Null
				END
			END			
			
		END
	END

	--RETURN

		IF EXISTS (SELECT WOPK 
						FROM WO 
						WHERE ProblemPK = @ProblemPK 
							AND AssetID = @AssetID
							AND Complete is null
							AND Status NOT IN ('CANCELED', 'DENIED', 'CLOSED'))
			BEGIN
				SET @DuplicateWO = 1
			END

		IF EXISTS (SELECT WOPK 
						FROM WO 
						WHERE ProblemPK = @ProblemPK 
							AND LEFT(AssetID,3) = LEFT(@AssetID,3)
							AND Complete is null
							AND Status NOT IN ('CANCELED', 'DENIED', 'CLOSED')
							AND DATEDIFF(MINUTE,Requested,getdate())<2)
			BEGIN
				SET @DuplicateWO = 2
			END

	---------------------------------------------------------------------------------------------------
	-- CREATE NEW WORK ORDER
	---------------------------------------------------------------------------------------------------

	DECLARE @RequesterPK As int
	DECLARE @RequesterID As varchar(25)
	DECLARE @HoldRequesterName As varchar(50)

	DECLARE @AssetName As varchar(150)

	DECLARE @WarrantyExpire As DateTime
	DECLARE @WarrantyBox As bit

	DECLARE @ProcedureID As varchar(25)
	DECLARE @ProcedureName As varchar(100)
		
	DECLARE @AccountPK int
	DECLARE @AccountID varchar(25)
	DECLARE @AccountName varchar(50)

	DECLARE @HoldAccountPK int
	DECLARE @HoldAccountID varchar(25)
	DECLARE @HoldAccountName varchar(50)

	DECLARE @RepairCenterID varchar(25)
	DECLARE @RepairCenterName varchar(50)

	DECLARE @HoldRepairCenterPK int
	DECLARE @HoldRepairCenterID varchar(25)
	DECLARE @HoldRepairCenterName varchar(50)

	DECLARE @ShopPK int
	DECLARE @ShopID varchar(25)
	DECLARE @ShopName varchar(50)

	DECLARE @HoldShopPK int
	DECLARE @HoldShopID varchar(25)
	DECLARE @HoldShopName varchar(50)

	DECLARE @HoldSupervisorPK int
	DECLARE @HoldSupervisorID varchar(25)
	DECLARE @HoldSupervisorName varchar(50)

	DECLARE @DepartmentPK int
	DECLARE @DepartmentID varchar(25)
	DECLARE @DepartmentName varchar(50)

	DECLARE @HoldDepartmentPK int
	DECLARE @HoldDepartmentID varchar(25)
	DECLARE @HoldDepartmentName varchar(50)

	DECLARE @TenantPK int
	DECLARE @TenantID varchar(25)
	DECLARE @TenantName varchar(50)

	DECLARE @HoldTenantPK int
	DECLARE @HoldTenantID varchar(25)
	DECLARE @HoldTenantName varchar(50)

	DECLARE @HoldStockRoomPK int
	DECLARE @HoldStockRoomID varchar(25)
	DECLARE @HoldStockRoomName varchar(50)

	DECLARE @HoldToolRoomPK int
	DECLARE @HoldToolRoomID varchar(25)
	DECLARE @HoldToolRoomName varchar(50)
			
	DECLARE @Account_RecordFound bit
	DECLARE @RepairCenter_RecordFound bit
	DECLARE @Shop_RecordFound bit
	DECLARE @Department_RecordFound bit
	DECLARE @Tenant_RecordFound bit

	SET @HoldAccountPK = Null
	SET @HoldAccountID = ''
	SET @HoldAccountName = ''

	SET @HoldRepairCenterPK = Null
	SET @HoldRepairCenterID = ''
	SET @HoldRepairCenterName = ''

	SET @HoldShopPK = Null
	SET @HoldShopID = ''
	SET @HoldShopName = ''

	SET @HoldSupervisorPK = Null
	SET @HoldSupervisorID = ''
	SET @HoldSupervisorName = ''

	SET @HoldDepartmentPK = Null
	SET @HoldDepartmentID = ''
	SET @HoldDepartmentName = ''

	SET @HoldTenantPK = Null
	SET @HoldTenantID = ''
	SET @HoldTenantName = ''

	SET @HoldStockRoomPK = Null
	SET @HoldStockRoomID = ''
	SET @HoldStockRoomName = ''

	SET @HoldToolRoomPK = Null
	SET @HoldToolRoomID = ''
	SET @HoldToolRoomName = ''

	SET @Account_RecordFound = 0
	SET @RepairCenter_RecordFound = 0
	SET @Shop_RecordFound = 0
	SET @Department_RecordFound = 0
	SET @Tenant_RecordFound = 0


	IF @AssetID Is Null 
	BEGIN
		SELECT @AssetID = AssetID, 
			   @AssetName = AssetName,
			   @WarrantyExpire = WarrantyExpire
		FROM Asset
		WHERE AssetPK = @AssetPK
	END
	ELSE
	BEGIN
		SELECT @AssetPK = AssetPK, 
			   @AssetName = AssetName,
			   @WarrantyExpire = WarrantyExpire
		FROM Asset
		WHERE AssetID = @AssetID
		
		
		
		
		
IF EXISTS(
SELECT ISUP from Asset WHERE AssetPK IN (SELECT AssetPK FROM dbo.MC_GetAssetParentPK (@AssetPK)) AND IsUp = 0)
BEGIN
	SET @response = 1
	RETURN @response
END
ELSE
BEGIN
		IF Not @@RowCount > 0
		BEGIN
			SELECT @AssetPK = AssetPK,
				   @AssetID = AssetID, 
				   @AssetName = AssetName,
				   @WarrantyExpire = WarrantyExpire
			FROM Asset
			WHERE AssetName = @AssetID	

			IF Not @@RowCount > 0
			BEGIN
				SELECT @AssetID = AssetID, 
					   @AssetName = AssetName,
					   @WarrantyExpire = WarrantyExpire
				FROM Asset
				WHERE AssetPK = @AssetPK	
			END			
		END		
	END

	IF @AssetPK Is Null
	BEGIN
		SET @Reason = RTRIM(LEFT(@Subject + ': ' + @Reason,2000))
	END

	If @ProcedurePK Is Not Null 
	BEGIN
		SELECT @ProcedureID = ProcedureID,
			   @ProcedureName = ProcedureName
		FROM ProcedureLibrary
		WHERE ProcedurePK = @ProcedurePK
	END

	SELECT @RequesterPK = LaborPK,
		   @RequesterID = LaborID,
		   @HoldRequesterName = LaborName
	FROM Labor
	WHERE Email = @RequesterEmail

	If @RequesterPK Is Null
	BEGIN
		SELECT TOP 1 @RequesterPK = Labor.LaborPK,
					 @RequesterID = Labor.LaborID,
					 @HoldRequesterName = Labor.LaborName
		FROM AssetRequester INNER JOIN Labor ON Labor.LaborPK = AssetRequester.LaborPK
		WHERE Labor.Email = @RequesterEmail
	END

	If @RequesterPK Is Not Null and @HoldRequesterName Is Not Null
	BEGIN
		SET @RequesterName = @HoldRequesterName
	END

	If @AssetPK Is Null and @RequesterPK Is Not Null
	BEGIN
		SELECT @AssetPK = WorkLocationPK
		FROM Labor
		WHERE LaborPK = @RequesterPK

		If @AssetPK Is Not Null
		BEGIN
			SELECT @AssetID = AssetID, 
				   @AssetName = AssetName,
				   @WarrantyExpire = WarrantyExpire
			FROM Asset
			WHERE AssetPK = @AssetPK	
		END	
	END

	-- =========================================================
	-- Check Warranty Info
	-- =========================================================
						
	IF @WarrantyExpire Is Not Null
	BEGIN
		IF @WarrantyExpire >= getDate()
		BEGIN
			Set @WarrantyBox = 1
		END
		Else
		BEGIN
			Set @WarrantyBox = 0
		END
	END
	ELSE
	BEGIN
		Set @WarrantyBox = 0
	END

	If @AssetPK Is Not Null
	BEGIN
				 
		DECLARE ASWalkTree_cursor INSENSITIVE CURSOR
		FOR
			Select Asset.AccountPK, Asset.AccountID, Asset.AccountName,
				   Asset.RepairCenterPK, Asset.RepairCenterID, Asset.RepairCenterName,
				   Asset.ShopPK, Asset.ShopID, Asset.ShopName, Asset.DepartmentPK, Asset.DepartmentID, Asset.DepartmentName,
				   Asset.TenantPK, Asset.TenantID, Asset.TenantName
			From  Asset INNER JOIN
				  AssetHierarchy ON Asset.AssetPK = AssetHierarchy.AssetPK 
				  INNER JOIN MC_GetAssetParentPK(@AssetPK) AAO on AAO.AssetPK = Asset.AssetPK
			Order By AAO.lvl
		FOR READ ONLY
					  
		OPEN ASWalkTree_cursor
		FETCH NEXT FROM ASWalkTree_cursor INTO  
		@AccountPK, @AccountID, @AccountName,
		@RepairCenterPK, @RepairCenterID, @RepairCenterName,
		@ShopPK, @ShopID, @ShopName, @DepartmentPK, @DepartmentID, @DepartmentName,
		@TenantPK, @TenantID, @TenantName
					 
		WHILE @@FETCH_STATUS = 0
		BEGIN
					 
			IF (@AccountPK Is Not Null and @Account_RecordFound = 0)
			BEGIN	
				SELECT @HoldAccountPK = @AccountPK, @HoldAccountID = @AccountID, @HoldAccountName = @AccountName
				SET @Account_RecordFound = 1
			END

			IF (@RepairCenterPK Is Not Null and @RepairCenter_RecordFound = 0)
			BEGIN	
				SELECT @HoldRepairCenterPK = @RepairCenterPK, @HoldRepairCenterID = @RepairCenterID, @HoldRepairCenterName = @RepairCenterName
				SET @RepairCenter_RecordFound = 1
			END

			IF (@ShopPK Is Not Null and @Shop_RecordFound = 0)
			BEGIN	
				SELECT @HoldShopPK = @ShopPK, @HoldShopID = @ShopID, @HoldShopName = @ShopName
				SET @Shop_RecordFound = 1
			END

			IF (@DepartmentPK Is Not Null and @Department_RecordFound = 0)
			BEGIN	
				SELECT @HoldDepartmentPK = @DepartmentPK, @HoldDepartmentID = @DepartmentID, @HoldDepartmentName = @DepartmentName
				SET @Department_RecordFound = 1
			END

			IF (@TenantPK Is Not Null and @Tenant_RecordFound = 0)
			BEGIN	
				SELECT @HoldTenantPK = @TenantPK, @HoldTenantID = @TenantID, @HoldTenantName = @TenantName
				SET @Tenant_RecordFound = 1
			END

			IF @Account_RecordFound = 1 AND
			   @RepairCenter_RecordFound = 1 AND
			   @Shop_RecordFound = 1 AND
			   @Department_RecordFound = 1 AND
			   @Tenant_RecordFound = 1
			BEGIN
				BREAK
			END
						  
			FETCH NEXT FROM ASWalkTree_cursor INTO  
			@AccountPK, @AccountID, @AccountName,
			@RepairCenterPK, @RepairCenterID, @RepairCenterName,
			@ShopPK, @ShopID, @ShopName, @DepartmentPK, @DepartmentID, @DepartmentName,
			@TenantPK, @TenantID, @TenantName
					  
		END

		CLOSE ASWalkTree_cursor
		DEALLOCATE ASWalkTree_cursor
		
	END

	-- Do we have a Repair Center? If not - then get one!
	If @HoldRepairCenterPK Is Null 
	BEGIN
		SELECT TOP 1 @HoldRepairCenterPK = RepairCenterPK,
					 @HoldRepairCenterID = RepairCenterID,
					 @HoldRepairCenterName = RepairCenterName,
					 @HoldStockRoomPK = StockRoomPK,
					 @HoldStockRoomID = StockRoomID,
					 @HoldStockRoomName = StockRoomName,						 
					 @HoldToolRoomPK = ToolRoomPK,
					 @HoldToolRoomID = ToolRoomID,
					 @HoldToolRoomName = ToolRoomName
		FROM RepairCenter
		WHERE DefaultRepairCenter = 1				
	END
	ELSE
	BEGIN
		SELECT TOP 1 @HoldStockRoomPK = StockRoomPK,
					 @HoldStockRoomID = StockRoomID,
					 @HoldStockRoomName = StockRoomName,						 
					 @HoldToolRoomPK = ToolRoomPK,
					 @HoldToolRoomID = ToolRoomID,
					 @HoldToolRoomName = ToolRoomName
		FROM RepairCenter
		WHERE RepairCenterPK = @HoldRepairCenterPK						
	END

	SET @RepairCenterPK = @HoldRepairCenterPK
			
	-- If there is a shop - then grab the supervisor of the shop - as the Work Order needs this information
	If @HoldShopPK Is Not Null
	BEGIN
		SELECT @HoldSupervisorPK = SupervisorPK, @HoldSupervisorID = SupervisorID, @HoldSupervisorName = SupervisorName
		FROM Shop
		WHERE ShopPK = @HoldShopPK
	END

	IF @DepartmentPK2 Is Not Null
	BEGIN
		SET @HoldDepartmentPK = @DepartmentPK2
		SET @HoldDepartmentID = @DepartmentID2
		SET @HoldDepartmentName = @DepartmentName2
	END

	Declare @PreferenceOutput varchar(50)
	Declare	@PreferenceDescOutput varchar(50)
	Declare	@PreferencePKOutput int
						
	Declare @Hold_TargetHours Decimal(19,6)
	Declare @Hold_Reference varchar(50)
	Declare @Hold_ReferenceDesc varchar(50)
	Declare @Hold_Priority varchar(50)
	Declare @Hold_PriorityDesc varchar(50)
	Declare @Hold_Type varchar(50)
	Declare @Hold_TypeDesc varchar(50)

	EXEC MC_GetRepairCenterPrefs @HoldRepairCenterPK, 'WO_DefaultTargetHours', 1, Null, @PreferenceOutput Output
	Set @Hold_TargetHours = Convert(Decimal(19,6),RTrim(@PreferenceOutput))

	EXEC MC_GetRepairCenterPrefs @HoldRepairCenterPK, 'WO_DefaultReference', 1, Null, @PreferenceOutput Output, @PreferenceDescOutput Output
	Set @Hold_Reference = RTrim(@PreferenceOutput)
	Set @Hold_ReferenceDesc = RTrim(@PreferenceDescOutput)

	IF @Priority Is Null
	BEGIN
		EXEC MC_GetRepairCenterPrefs @HoldRepairCenterPK, 'WO_DefaultPriority', 1, Null, @PreferenceOutput Output, @PreferenceDescOutput Output
		Set @Hold_Priority = RTrim(@PreferenceOutput)
		Set @Hold_PriorityDesc = RTrim(@PreferenceDescOutput)
	END
	ELSE
	BEGIN
		Set @Hold_Priority = @Priority
		Set @Hold_PriorityDesc = @PriorityDesc
	END

	EXEC MC_GetRepairCenterPrefs @HoldRepairCenterPK, 'WO_DefaultType', 1, Null, @PreferenceOutput Output, @PreferenceDescOutput Output
	Set @Hold_Type = RTrim(@PreferenceOutput)
	Set @Hold_TypeDesc = RTrim(@PreferenceDescOutput)

	-- =========================================================
	-- Get Authorization Status
	-- =========================================================

	Declare @Hold_WOAuthStatus varchar(25)	
	Declare @Hold_WOAuthStatusDesc varchar(50)	

	EXEC MC_GetRepairCenterPrefs @HoldRepairCenterPK, 'WO_DefaultAuth', 1, Null, @PreferenceOutput Output, @PreferenceDescOutput Output
	Set @Hold_WOAuthStatus = RTrim(@PreferenceOutput)
	Set @Hold_WOAuthStatusDesc = RTrim(@PreferenceDescOutput)

	IF @Hold_WOAuthStatus IN ('REQUIRED1','REQUIRED2','REQUIRED3','REQUIRED4','REQUIRED5')
	BEGIN
		SET @Hold_WOAuthStatus = @Hold_WOAuthStatus
		SET @Hold_WOAuthStatusDesc = @Hold_WOAuthStatusDesc						
	END
	ELSE
	BEGIN
		SET @Hold_WOAuthStatus = 'NOTREQUIRED'
		SET @Hold_WOAuthStatusDesc = '(Not Required)'
	END
	-- Get the procedure from the failure if it is not preset.  On insert, a WO trigger will link any tasks for the procedure
	IF @ProblemPK Is Not Null AND @ProcedurePK Is Null
	Begin
		SELECT @ProcedurePK = p.ProcedurePK, @ProcedureID = p.ProcedureID, @ProcedureName = p.ProcedureName
			FROM Failure f WITH (NOLOCK) INNER JOIN ProcedureLibrary p WITH (NOLOCK) ON f.ProcedurePK = p.ProcedurePK
			WHERE FailurePK = @ProblemPK
	END
							
	IF @ProcedurePK Is Not Null
	BEGIN
		declare @sql varchar(max), @sqls varchar(max)
		select @sql = 	
		'INSERT INTO WO
	         (WOID, Reason, RequesterPK, RequesterID, RequesterName, RequesterEmail, Status, StatusDesc, AuthStatus, AuthStatusDesc, AuthLevelsRequired, StatusDate, AssetPK, AssetID, AssetName, AccountPK, AccountID, 
	         AccountName, ProcedurePK, ProcedureID, ProcedureName, StockRoomPK, StockRoomID, StockRoomName, ToolRoomPK, ToolRoomID, 
	         ToolRoomName, TargetDate, TargetHours, Type, TypeDesc, Priority, PriorityDesc, RepairCenterPK, RepairCenterID, RepairCenterName, SupervisorPK, 
	         SupervisorID, SupervisorName, ShopPK, ShopID, ShopName, DepartmentPK, DepartmentID, DepartmentName, TenantPK, TenantID, TenantName, 
	         WarrantyBox, ShutdownBox, LockoutTagoutBox, AttachmentsBox, SurveyBox, Survey_ID, ProblemPK, ProblemID, ProblemName, IsOpen, CategoryPK, 
	         CategoryID, CategoryName, TakenByInitials, Instructions, ProjectPK, ProjectID, ProjectName, Reference, ReferenceDesc, Chargeable, RowVersionAction, UDFChar5)'
		select @sqls =	         
		'SELECT  
			 WOID = '''',
			 Reason = ''+ LEFT(@Reason, 6) 
			 +''','+ @RequesterPK  +',
			 '+ @RequesterID +',
			 '+ @RequesterName +',
			 '+ @RequesterEmail +',
				 CASE WHEN '+ @DuplicateWO +' <> 0 OR '+ @CloseWO +' = 1 THEN ''CANCELED'' ELSE ''REQUESTED'' END, 
				 CASE WHEN '+ @DuplicateWO +' <> 0 OR '+ @CloseWO +' = 1 THEN ''Canceled'' ELSE ''Requested'' END,
			 AuthStatus = CASE
			 WHEN WOAuthStatus Is Null or WOAuthStatus = '''' THEN '+ @Hold_WOAuthStatus +'
			 ELSE WOAuthStatus
			 END, 
			 AuthStatusDesc = CASE
			 WHEN WOAuthStatus Is Null or WOAuthStatus = '''' THEN '+ @Hold_WOAuthStatusDesc +'
			 ELSE WOAuthStatusDesc
			 END, 
			 0, 
			 getDate(),  
			 '+ @AssetPK +', 
			 '+ @AssetID +', 
			 '+ @AssetName +', 
			 '+ @HoldAccountPK +', 
			 '+ @HoldAccountID +', 
	         '+ @HoldAccountName +', 
	         '+ @ProcedurePK +', 
	         '+ @ProcedureID +', 
	         '+ @ProcedureName +', 
	         '+ @HoldStockRoomPK +', 
	         '+ @HoldStockRoomID +', 
	         '+ @HoldStockRoomName +', 
	         '+ @HoldToolRoomPK +', 
	         '+ @HoldToolRoomID +', 
	         '+ @HoldToolRoomName +', 
	         getDate(), 
	         TargetHours = CASE
	         WHEN TargetHours Is Null or TargetHours = '''' THEN '+ @Hold_TargetHours +'
	         ELSE TargetHours
	         END, 
	         Type = CASE
	         WHEN Type Is Null or Type = '''' THEN '+ @Hold_Type +'
	         ELSE Type
	         END, 
	         TypeDesc = CASE
	         WHEN Type Is Null or Type = '''' THEN '+ @Hold_TypeDesc +'
	         ELSE TypeDesc
	         END, 
	         Priority = CASE
	         WHEN Priority Is Null or Priority = '''' THEN '+ @Hold_Priority +'
	         ELSE Priority
	         END, 
	         PriorityDesc = CASE
	         WHEN Priority Is Null or Priority = '''' THEN '+ @Hold_PriorityDesc +'
	         Else PriorityDesc
	         END, 
	         '+ @HoldRepairCenterPK +', 
	         '+ @HoldRepairCenterID +', 
	         '+ @HoldRepairCenterName +', 
	         '+ @HoldSupervisorPK +', 
	         '+ @HoldSupervisorID +', 
	         '+ @HoldSupervisorName +', 
	         '+ @HoldShopPK +', 
	         '+ @HoldShopID +', 
	         '+ @HoldShopName +', 
	         '+ @HoldDepartmentPK +', 
	         '+ @HoldDepartmentID +', 
	         '+ @HoldDepartmentName +', 
	         '+ @HoldTenantPK +', 
	         '+ @HoldTenantID +',
	         '+ @HoldTenantName +',
	         '+ @WarrantyBox +', 
	         ShutdownBox, 
	         LockoutTagoutBox, 
	         AttachmentsBox, 
	         0, 
	         Null,' +
	         @ProblemPK +', '+
	         @ProblemID +', '+
	         @ProblemName +',
				 CASE WHEN @DuplicateWO <> 0 THEN 0 ELSE 1 END, 
	         CategoryPK, 
	         CategoryID, 
	         CategoryName, 
	         ''_MC'', 
			 Instructions,
			 ProjectPK,
			 ProjectID,
			 ProjectName,
	         Reference = CASE
	         WHEN Reference Is Null or Reference = '''' THEN ' + @Hold_Reference +'
	         ELSE Reference
	         END, 
	         ReferenceDesc = CASE
	         WHEN Reference Is Null or Reference = '''' THEN ' + @Hold_ReferenceDesc +'
	         Else ReferenceDesc
	         END,
	         Chargeable,
	         ''SR'',
	         @UDFChar5
	FROM ProcedureLibrary
	WHERE ProcedurePK =' --+ @ProcedurePK

		SELECT @sql, @sqls
	END
	ELSE
	BEGIN
			
		INSERT INTO WO
				 (WOID, Reason, RequesterPK, RequesterID, RequesterName, RequesterEmail, Status, StatusDesc, AuthStatus, AuthStatusDesc, AuthLevelsRequired, StatusDate, AssetPK, AssetID, AssetName, AccountPK, AccountID, 
				 AccountName, ProcedurePK, ProcedureID, ProcedureName, StockRoomPK, StockRoomID, StockRoomName, ToolRoomPK, ToolRoomID, 
				 ToolRoomName, TargetDate, TargetHours, Type, TypeDesc, Priority, PriorityDesc, RepairCenterPK, RepairCenterID, RepairCenterName, SupervisorPK, 
				 SupervisorID, SupervisorName, ShopPK, ShopID, ShopName, DepartmentPK, DepartmentID, DepartmentName, TenantPK, TenantID, TenantName, 
				 WarrantyBox, ShutdownBox, LockoutTagoutBox, AttachmentsBox, SurveyBox, Survey_ID, ProblemPK, ProblemID, ProblemName, IsOpen, CategoryPK, 
				 CategoryID, CategoryName, TakenByInitials, Instructions, ProjectPK, ProjectID, ProjectName, Reference, ReferenceDesc, Chargeable, RowVersionAction, UDFChar5)
		SELECT  
				 WOID = '',
				 Reason = @Reason,
				 @RequesterPK,
				 @RequesterID,
				 @RequesterName,
				 @RequesterEmail,
				 CASE WHEN @DuplicateWO <> 0 OR @CloseWO = 1 THEN 'CANCELED' ELSE 'REQUESTED' END, -- Status
				 CASE WHEN @DuplicateWO <> 0 OR @CloseWO = 1 THEN 'Canceled' ELSE 'Requested' END, -- StatusDesc
				 @Hold_WOAuthStatus, 
				 @Hold_WOAuthStatusDesc,
				 0, --AuthLevelsRequired
				 getDate(), -- StatusDate 
				 @AssetPK, 
				 @AssetID, 
				 @AssetName, 
				 @HoldAccountPK, 
				 @HoldAccountID, 
				 @HoldAccountName, 
				 @ProcedurePK, 
				 @ProcedureID, 
				 @ProcedureName, 
				 @HoldStockRoomPK, 
				 @HoldStockRoomID, 
				 @HoldStockRoomName, 
				 @HoldToolRoomPK, 
				 @HoldToolRoomID, 
				 @HoldToolRoomName, 
				 getDate(), -- TargetDate
				 @Hold_TargetHours,
				 @Hold_Type,
				 @Hold_TypeDesc,
				 @Hold_Priority,
				 @Hold_PriorityDesc,
				 @HoldRepairCenterPK, 
				 @HoldRepairCenterID, 
				 @HoldRepairCenterName, 
				 @HoldSupervisorPK, 
				 @HoldSupervisorID, 
				 @HoldSupervisorName, 
				 @HoldShopPK, 
				 @HoldShopID, 
				 @HoldShopName, 
				 @HoldDepartmentPK, 
				 @HoldDepartmentID, 
				 @HoldDepartmentName, 
				 @HoldTenantPK, 
				 @HoldTenantID, 
				 @HoldTenantName, 
				 @WarrantyBox, 
				 0, 
				 0, 
				 0, 
				 0, -- @SurveyBox
				 Null, -- @Survey_ID
				 @ProblemPK, -- ProblemPK 
				 @ProblemID, -- ProblemID 
				 @ProblemName, --ProblemName 
				 CASE WHEN @DuplicateWO <> 0 THEN 0 ELSE 1 END, -- IsOpen 
				 @HoldCategoryPK, 
				 @HoldCategoryID, 
				 @HoldCategoryName, 
				 '_MC', -- TakenByInitials
				 Null,
				 Null,
				 Null,
				 Null,
				 @Hold_Reference,
				 @Hold_ReferenceDesc,
				 0,
				 'SR',
				 @UDFChar5
	END

	-- =========================================================
	-- Get the Primary Key for the New Work Order
	-- =========================================================

	SET @WOPK = SCOPE_IDENTITY()

	-- =========================================================
	-- Smart Transfer Fields
	-- =========================================================

	EXEC MC_SmartTransfer 'WO', 'WO', 'WOPK', @WOPK
																	
	-- =========================================================
	-- Calculate the Work Order
	-- =========================================================

	EXEC MC_CalcWorkOrder @WOPK

	-- =========================================================
	-- Reserve Parts if necessary
	-- =========================================================

	EXEC MC_ReserveUnreserveParts @WOPK, @AssetPK, Null, Null, Null

	-- =========================================================
	-- Auto-Assign if necessary
	-- =========================================================

	EXEC MC_WOAutoAssign @WOPK

	-- =========================================================
	-- Close if necessary
	-- =========================================================

	IF @CloseWO = 1
		BEGIN
			UPDATE WO 
				SET SubStatus = 'Alert'
					, SubStatusDesc = 'Alert'
					, Canceled = getdate()
					, Complete = getdate()
					, Closed = getdate()
					, IsOpen = 0
			WHERE WOPK = @WOPK
		END	

	IF @DuplicateWO = 1
		BEGIN
			UPDATE WO 
				SET SubStatus = 'DUPLICATE'
					, SubStatusDesc = 'Duplicate'
					, Canceled = getdate()
					, Complete = getdate()
					, Closed = getdate()
					, IsOpen = 0
			WHERE WOPK = @WOPK
		END
		
	IF @DuplicateWO = 2
		BEGIN
			UPDATE WO 
				SET SubStatus = 'PLAZA DUPLICATE'
					, SubStatusDesc = 'Plaza Duplicate'
					, Canceled = getdate()
					, Complete = getdate()
					, Closed = getdate()
					, IsOpen = 0
			WHERE WOPK = @WOPK
		END		

	RETURN 0
END

