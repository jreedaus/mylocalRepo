--SELECT ISUP from Asset WHERE AssetPK IN (SELECT AssetPK FROM dbo.MC_GetAssetParentPK (3	)) AND IsUp = 0
select * from procedurelibrary
--		update failure set procedurepk = 2 where failurepk = 69
SELECT p.ProcedurePK, p.ProcedureID, p.ProcedureName, f.*
FROM Failure f WITH (NOLOCK) INNER JOIN ProcedureLibrary p WITH (NOLOCK) ON f.ProcedurePK = p.ProcedurePK
WHERE FailurePK = 69

Declare @response int
execute MC_CreateWOFromURL 'Svc Req:BROKEN', null, null, null, 'B111', null, null, null, '[VECTOR INTERFACE]', @response