select problempk, problemid, problemname, failurepk, failureid, failurename, procedurepk, procedureid, procedurename, * from wo
order by wopk desc

select * from wotask order by wopk desc

--		update wo set woid = wopk

select * from failure order by 2	-- update failure set procedurePK = 4 where failurepk = 88


select top 100 * from entburtonc.dbo.procedurelibrary where categorypk is null and supervisorpk is null

select * from procedurelibrary


select * from asset

select * from category

--	http://localhost/mc_web60/acslanding.asp?database=ent60&body=SvcNeeded&Subject=B111-F9&rulename=none

--	http://localhost/mc_web60/acslanding.asp?database=ent60&body=Line1\13\10KITCH\13\10L3\13\10L4\13\10L5\13\10SvcNeeded\13\10L7\13\101&Subject=B111-F9&rulename=[VECTOR INTERFACE]

--	http://localhost/mc_web60/acslanding.asp?database=ent60&body=Line1\013\010KITCH\013\010L3\013\010L4\013\010L5\013\010SvcNeeded\013\010L7\013\0101&Subject=B111-F9&rulename=[VECTOR INTERFACE]

--	http://localhost/mc_web60/acslanding.asp?database=ent60&body=Line1\015\010KITCH\015\010L3\015\010L4\015\010L5\015\010SvcNeeded\015\010L7\015\0101&Subject=B111-F9&rulename=[VECTOR INTERFACE]

--	http://localhost/mc_web60/acslanding.asp?database=ent60&body=Line1<CR><LF>KITCH<CR><LF>L3<CR><LF>L4<CR><LF>L5<CR><LF>SvcNeeded<CR><LF>L7<CR><LF>1&Subject=B111-F9&rulename=[VECTOR INTERFACE]

--	http://localhost/mc_web60/acslanding.asp?database=ent60&body=Line1%0D%0AKITCH%0D%0AL3%0D%0AL4%0D%0AL5%0D%0ASvcNeeded%0D%0AL7%0D%0A1&Subject=B111-F9&rulename=[VECTOR%20INTERFACE]

http://localhost/mc_web60/acslanding.asp?database=ent60&body=Line1:KITCH:L3:L4:L5:SvcNeeded:L7:1&Subject=B111-F9&rulename=[VECTOR%20INTERFACE]

http://localhost/mc_web60/acslanding.asp?database=ent60&subject=B111-F9&body=ALARM_ID:KITCH:EQUIP_ID:GEN:TEXT:Test:Priority:1:Code::Security:&rulename=[VECTOR%20INTERFACE]
http://138.69.14.9/mc_web/acslanding.asp?database=entATL&subject=SRTA_GA400_LANE_GA400-BLDG-TUNNEL_20091009021800&body=ALARM_ID:COMM:EQUIP_ID:GEN:TEXT:Test work order, please ignore:Priority:1:Code::Security:&rulename=[VECTOR%20INTERFACE]

