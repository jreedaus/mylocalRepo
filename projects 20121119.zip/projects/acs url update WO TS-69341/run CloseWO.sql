--select * from WO order by 1 desc
declare @now datetime
	select @now = GETDATE()		
	exec MC_CloseWorkOrder 99,'20121116 14:35:00','A    '
		,@now,'A    '			
		,1,@now,'A    '		
		,0,@now,'A    ',1			
		,0,@now,'A    '			
		,0,@now,'A    ',			
		NULL,3,NULL,NULL,NULL,0,0,-1,NULL,NULL,0,0,NULL,0,0,0,0,
		NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,'WO','Y',44,'_MC',NULL,NULL,0,0,0,NULL,NULL,0,0

declare @argWOID varchar(50)
declare	@argAction varchar(50)	
declare	@resp varchar(500), @response varchar(500)

SELECT @argWOID = 'M-104', @argAction ='ONHOLD'
exec MC_UpdateWOFromURL @argWOID, @argAction, @response=@resp OUTPUT 

SELECT @resp

/*
	update wo set status = 'REQUESTED', statusdesc = 'Requested', issued = null, issuedinitials = null,
		responded = null, respondedinitials = null,
		complete = null, completedinitials = null,
		finalized = null, finalizedinitials = null,
		closed = null, closedinitials = null,
		requested = '2012-11-15 16:16:13.000',
		isopen = 1
		where  wopk = 99
		
	delete from wostatushistory where (Status = 'CLOSED' OR Status = 'ISSUED') and wopk = 99
	
*/