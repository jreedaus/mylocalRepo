DECLARE @RC int
DECLARE @WOPK int
DECLARE @requesteddate datetime
DECLARE @requestedinitials char(5)
DECLARE @issueddate datetime
DECLARE @issuedinitials char(5)
DECLARE @responded bit
DECLARE @respondeddate datetime
DECLARE @respondedinitials char(5)
DECLARE @completed bit
DECLARE @completeddate datetime
DECLARE @completedinitials char(5)
DECLARE @completedassignments bit
DECLARE @finalized bit
DECLARE @finalizeddate datetime
DECLARE @finalizedinitials char(5)
DECLARE @closed bit
DECLARE @closeddate datetime
DECLARE @closedinitials char(5)
DECLARE @laborreport varchar(6000)
DECLARE @lri smallint
DECLARE @txtaccountpk int
DECLARE @txtaccount varchar(25)
DECLARE @txtaccountdesc varchar(50)
DECLARE @txtAccountAll bit
DECLARE @txtchargeable bit
DECLARE @txtcategorypk int
DECLARE @txtcategory varchar(25)
DECLARE @txtcategorydesc varchar(50)
DECLARE @txtCategoryAll bit
DECLARE @txtTasks bit
DECLARE @txtTaskInitials varchar(5)
DECLARE @txtLabor1 bit
DECLARE @txtLabor3 bit
DECLARE @txtMaterials bit
DECLARE @txtOtherCost bit
DECLARE @txtproblempk int
DECLARE @txtproblem varchar(25)
DECLARE @txtproblemdesc varchar(50)
DECLARE @txtfailurepk int
DECLARE @txtfailure varchar(25)
DECLARE @txtfailuredesc varchar(50)
DECLARE @txtsolutionpk int
DECLARE @txtsolution varchar(25)
DECLARE @txtsolutiondesc varchar(50)
DECLARE @txtfailurewo bit
DECLARE @txtmeter1reading int
DECLARE @txtmeter2reading int
DECLARE @txtisup bit
DECLARE @txtDrawingUpdatesNeeded bit
DECLARE @mode varchar(15)
DECLARE @woauth char(1)
DECLARE @RowVersionUserPK int
DECLARE @RowVersionInitials varchar(5)
DECLARE @RowVersionIPAddress varchar(25)
DECLARE @txtMyLaborHrs varchar(15)
DECLARE @txtRESPONDEDOVERWRITE bit
DECLARE @txtCOMPLETEDOVERWRITE bit
DECLARE @txtFINALIZEDOVERWRITE bit
DECLARE @txtMyLaborHrsPK int
DECLARE @txtMyLaborOHrs varchar(15)
DECLARE @txtFollowUpSingleWO bit
DECLARE @txtFollowUpMultiWO bit

-- TODO: Set parameter values here.
-- responded
------exec MC_CloseWorkOrder 50,'20121030 14:35:00','A    ','20121118 11:26:00','A    ',1,'20121118 11:26:00','A    ',0,'20121118 11:26:00',NULL,1,
------0,'20121118 11:26:00',NULL,0,'20121118 11:26:00',NULL,
------NULL,3,NULL,NULL,NULL,0,0,-1,NULL,NULL,0,0,NULL,0,0,0,0,
------NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,'WO','Y',44,'A','::1',NULL,0,0,0,NULL,NULL,0,0
-- completed
------exec MC_CloseWorkOrder 50,'20121030 14:35:00','A    ','20121118 11:26:00','A    ',1,'20121118 11:26:00','A    ',1,'20121118 11:46:00','A    ',1,
------0,'20121118 11:46:00',NULL,0,'20121118 11:46:00',NULL,
------NULL,3,NULL,NULL,NULL,0,0,-1,NULL,NULL,0,0,NULL,0,0,0,0,
------NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,'WO','Y',44,'A','::1',NULL,0,0,0,NULL,NULL,0,0
-- finalized
------exec MC_CloseWorkOrder 50,'20121030 14:35:00','A    ','20121118 11:26:00','A    ',1,'20121118 11:26:00','A    ',1,'20121118 11:46:00','A    ',1,
------1,'20121118 12:21:00','A    ',0,'20121118 12:21:00',NULL,
------NULL,3,NULL,NULL,NULL,0,0,-1,NULL,NULL,0,0,NULL,0,0,0,0,
------NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,'WO','Y',44,'A','::1',NULL,0,0,0,NULL,NULL,0,0
-- closed
------exec MC_CloseWorkOrder 50,'20121030 14:35:00','A    ','20121118 11:26:00','A    ',1,'20121118 11:26:00','A    ',1,'20121118 11:46:00','A    ',1,
------1,'20121118 12:21:00','A    ',1,'20121118 12:26:00','A    ',
------NULL,3,NULL,NULL,NULL,0,0,-1,NULL,NULL,0,0,NULL,0,0,0,0,
------NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,'WO','Y',44,'A','::1',NULL,0,0,0,NULL,NULL,0,0
EXECUTE @RC = [ENT60].[dbo].[MC_CloseWorkOrder] 
   @WOPK
  ,@requesteddate
  ,@requestedinitials
  ,@issueddate
  ,@issuedinitials
  ,@responded
  ,@respondeddate
  ,@respondedinitials
  ,@completed
  ,@completeddate
  ,@completedinitials
  ,@completedassignments
  ,@finalized
  ,@finalizeddate
  ,@finalizedinitials
  ,@closed
  ,@closeddate
  ,@closedinitials
  ,NULL					--@laborreport
  ,NULL					--@lri
  ,NULL					--@txtaccountpk
  ,NULL					--@txtaccount
  ,NULL					--@txtaccountdesc
  ,0					--@txtAccountAll
  ,0					--@txtchargeable
  ,-1					--@txtcategorypk
  ,NULL					--@txtcategory
  ,NULL					--@txtcategorydesc
  ,0					--@txtCategoryAll
  ,0					--@txtTasks
  ,NULL					--@txtTaskInitials
  ,0					--@txtLabor1
  ,0					--@txtLabor3
  ,0					--@txtMaterials
  ,0					--@txtOtherCost
  ,NULL					--@txtproblempk
  ,NULL					--@txtproblem
  ,NULL					--@txtproblemdesc
  ,NULL					--,@txtfailurepk
  ,NULL					--@txtfailure
  ,NULL					--@txtfailuredesc
  ,NULL					--@txtsolutionpk
  ,NULL					--@txtsolution
  ,NULL					--@txtsolutiondesc
  ,0					--@txtfailurewo
  ,0					--@txtmeter1reading
  ,0					--@txtmeter2reading
  ,0					--@txtisup
  ,0					--@txtDrawingUpdatesNeeded
  ,'WO'					--@mode
  ,'Y'					--@woauth
  ,NULL					--@RowVersionUserPK
  ,'_MC'				--@RowVersionInitials
  ,NULL					--@RowVersionIPAddress
  ,NULL					--@txtMyLaborHrs
  ,0					--@txtRESPONDEDOVERWRITE
  ,0					--@txtCOMPLETEDOVERWRITE
  ,0					--@txtFINALIZEDOVERWRITE
  ,NULL					--@txtMyLaborHrsPK
  ,NULL					--,@txtMyLaborOHrs
  ,0					--@txtFollowUpSingleWO
  ,0					--@txtFollowUpMultiWO
GO


