SELECT wopk, status, 
		Issued, IssuedInitials,
		responded,respondedinitials,
		complete,completedinitials,
       finalized,finalizedinitials,
       closed,closedinitials,       
       *
FROM   wo 
--WHERE WOID = 'M-107'
order by 1 desc

		--LookupTable		CodeName	CodeDesc
		--WOSTATUS       	CANCELED	Canceled
		--WOSTATUS       	CLOSED		Closed
		--WOSTATUS       	DENIED		Denied
		--WOSTATUS       	ISSUED		Issued
		--WOSTATUS       	ONHOLD		On-Hold
		--WOSTATUS       	REQUESTED	Requested
	
	-- for WO that is requested and set respond	
--UPDATE WO set Status ='ISSUED', StatusDesc='Issued', Responded = GETDATE(), RespondedInitials = '_MC', 
--StatusDate = GETDATE(), Issued = GETDATE(), IssuedInitials = '_MC', RowVersionAction = 'STATUS', RowVersionDate = GETDATE()	
--WHERE WOPK = 49
--	exec MC_CalcWorkOrder 50

SELECT * FROM WOAssign order by 1 desc
select * FROM WOAssignStatus order by 1 desc
--	Update WOAssignStatus SET completed = 1 WHERE WOPK = 50
-- 
--exec MC_CloseWorkOrder 50,
--requested   '20121030 14:35:00','A    ',
-- issued     '20121118 11:26:00','A    ',
--responded   1,'20121118 11:26:00','A    ',
--completed   0,'20121118 11:26:00',NULL,1,
--finalized   0,'20121118 11:26:00',NULL,
--closed      0,'20121118 11:26:00',NULL,
--NULL,3,NULL,NULL,NULL,0,0,-1,NULL,NULL,0,0,NULL,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,'WO','Y',44,'A','::1',NULL,0,0,0,NULL,NULL,0,0