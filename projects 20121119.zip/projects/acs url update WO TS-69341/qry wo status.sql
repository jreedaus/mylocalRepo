select * from WOStatusHistory 
--where WOPK = 99
order by 1 desc


---  delete wostatushistory where pk >=267