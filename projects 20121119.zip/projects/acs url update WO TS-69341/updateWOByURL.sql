
/****** Object:  StoredProcedure [dbo].[MC_UpdateWOFromURL]    Script Date: 11/17/2012 11:04:36 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


ALTER Procedure [dbo].[MC_UpdateWOFromURL]
(
	@argWOID varchar(50),
	@argAction varchar(50),	
	@response varchar(500) = '' output
)
As
SET NOCOUNT ON

DECLARE @retMessage varchar(500)
DECLARE @thisAction varchar(50)
DECLARE @currDate datetime
DECLARE @WOID varchar(50)
DECLARE @WOPK int
DECLARE @woStatus varchar(15)
DECLARE @woRequested datetime, @woRequestedInitials varchar(5)
DECLARE @woIssued datetime, @woIssuedInitials varchar(5)
DECLARE @woResponded datetime, @woRespondedInitials varchar(5), @isResponded int
DECLARE @woCompleted datetime, @woCompletedInitials varchar(5), @isCompleted int
DECLARE @woFinalized datetime, @woFinalizedInitials varchar(5), @isFinalized int
DECLARE @woClosed datetime, @woClosedInitials varchar(5), @isClosed int

DECLARE @runSP bit
SELECT @runSP = 0
SELECT @thisAction = RTRIM(LTRIM(@argAction))
SELECT @WOID = UPPER(RTRIM(LTRIM(@argWOID)))
SELECT @WOPK = 0
SELECT @retMessage = ''  -- init string
SELECT @currDate = GETDATE()
IF LEN(@WOID) > 0
BEGIN

	SELECT @WOPK = wopk,		
		   @woStatus = status,
		   @woRequested = requested, @woRequestedInitials = takenbyinitials,
		   @woIssued = issued, @woIssuedInitials = issuedinitials,
		   @isResponded = CASE WHEN responded IS NULL THEN 0 ELSE 1 END, @woResponded = responded, @woRespondedInitials = respondedinitials,
		   @isCompleted = CASE WHEN Complete IS NULL THEN 0 ELSE 1 END, @woCompleted = complete, @woCompletedInitials = completedinitials,
		   @isFinalized = CASE WHEN Finalized IS NULL THEN 0 ELSE 1 END, @woFinalized = finalized, @woFinalizedInitials = finalizedinitials,
		   @isClosed = CASE WHEN Closed IS NULL THEN 0 ELSE 1 END, @woClosed = closed, @woClosedInitials = closedinitials       
	FROM   wo
	WHERE  woid = @WOID 

--PRINT @WOID + ' - ' + CONVERT(VARCHAR(30), @WOPK)
--      + ' - ' + CONVERT(VARCHAR(30), @woStatus) + ' - Req '
--      + ISNULL(CONVERT(VARCHAR(30), @woRequested), '') + ' - '
--      + ISNULL(CONVERT(VARCHAR(30), @woRequestedInitials), '') + ' - Iss '
--      + ISNULL(CONVERT(VARCHAR(30), @woIssued), '') + ' - '
--      + ISNULL(CONVERT(VARCHAR(30), @woIssuedInitials), '') + ' - Resp '
--      + CONVERT(CHAR(1), @isResponded) + ' - '
--      + ISNULL(CONVERT(VARCHAR(30), @woResponded), '') + ' - '
--      + ISNULL(CONVERT(VARCHAR(30), @woRespondedInitials), '') + ' - Comp '
--      + CONVERT(CHAR(1), @isCompleted) + ' - '
--      + ISNULL(CONVERT(VARCHAR(30), @woCompleted), '') + ' - '
--      + ISNULL(CONVERT(VARCHAR(30), @woCompletedInitials), '') + ' - Fin '
--      + CONVERT(CHAR(1), @isFinalized) + ' - '
--      + ISNULL(CONVERT(VARCHAR(30), @woFinalized), '') + ' - '
--      + ISNULL(CONVERT(VARCHAR(30), @woFinalizedInitials), '') + ' - Close '
--      + CONVERT(CHAR(1), @isClosed) + ' - '
--      + ISNULL(CONVERT(VARCHAR(30), @woClosed), '') + ' - '
--      + ISNULL(CONVERT(VARCHAR(30), @woClosedInitials), '')
--end      
	IF @WOPK > 0
	BEGIN
		IF UPPER(@thisAction) = 'RESPONDED'
		BEGIN
			IF @woResponded IS NOT NULL 
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - this workorder was already responded to on ' + Convert(varchar(30), @woResponded) + ' by ' + @woRespondedInitials
			IF LEN(@retMessage) = 0 AND (UPPER(@woStatus) = 'REQUESTED' OR UPPER(@woStatus) = 'ONHOLD' OR UPPER(@woStatus) = 'ISSUED')
			BEGIN
				SELECT @runSP = 1
				SELECT @isResponded = 1, @woResponded = @currDate, @woRespondedInitials = '_MC'
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order successfully marked as Responded'
				--PRINT 'UPDATE WO SET status = ISSUED, statusdesc =Issued responded = @currDate, respondedinitials = _MC WHERE WOPK = ' +Convert(varchar(10), @WOPK)
				--PRINT 'INSERT INTO WOStatusHistory SELECT @WOPK, 0, @currDate, ISSUED, Issued, NULL, NULL, NULL, _MC, @currDate, 0'
			END	
			ELSE
			BEGIN
				IF LEN(@retMessage) = 0			
					SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order cannot be RESPONDED to because the status is: ' + @woStatus 
			END		
		END
		ELSE IF UPPER(@thisAction) = 'COMPLETED'
		BEGIN
			IF @woCompleted IS NOT NULL 
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - this workorder was already completed on ' + Convert(varchar(30), @woCompleted) + ' by ' + @woCompletedInitials
			IF LEN(@retMessage) = 0 AND (UPPER(@woStatus) = 'REQUESTED' OR UPPER(@woStatus) = 'ONHOLD' OR UPPER(@woStatus) = 'ISSUED')
			BEGIN
				SELECT @runSP = 1
				SELECT @isCompleted = 1, @woCompleted = @currDate, @woCompletedInitials = '_MC'
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order successfully marked as Completed'			
			END	
			ELSE
			BEGIN
				IF LEN(@retMessage) = 0			
					SELECT @retMessage = @retMessage +' = '+ @WOID +' - Completed can not be applied since the status of this workorder is: ' + @woStatus 
			END
		END
		ELSE IF UPPER(@thisAction) = 'FINALIZED'
		BEGIN
			IF @woFinalized IS NOT NULL 
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - this workorder was already finalized on ' + Convert(varchar(30), @woFinalized) + ' by ' + @woFinalizedInitials
			IF LEN(@retMessage) = 0 AND (UPPER(@woStatus) = 'REQUESTED' OR UPPER(@woStatus) = 'ONHOLD' OR UPPER(@woStatus) = 'ISSUED')
			BEGIN
				SELECT @runSP = 1
				SELECT @isFinalized = 1, @woFinalized = @currDate, @woFinalizedInitials = '_MC'
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order successfully marked as Finalized'			
			END	
			ELSE
			BEGIN
				IF LEN(@retMessage) = 0			
					SELECT @retMessage = @retMessage +' = '+ @WOID +' - Finalized can not be applied since the status of this workorder is: ' + @woStatus 
			END
		END	
		ELSE IF UPPER(@thisAction) = 'CLOSED'
		BEGIN
			IF @woClosed IS NOT NULL 
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - this workorder was already closed on ' + Convert(varchar(30), @woClosed) + ' by ' + @woClosedInitials
			IF LEN(@retMessage) = 0 AND (UPPER(@woStatus) = 'REQUESTED' OR UPPER(@woStatus) = 'ONHOLD' OR UPPER(@woStatus) = 'ISSUED')
			BEGIN
				SELECT @runSP = 1
				SELECT @isClosed = 1, @woClosed = @currDate, @woClosedInitials = '_MC'
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order successfully marked as Closed'			
			END	
			ELSE
			BEGIN
				IF LEN(@retMessage) = 0			
					SELECT @retMessage = @retMessage +' = '+ @WOID +' - Closed can not be applied since the status of this workorder is: ' + @woStatus 
			END
		END
		ELSE IF UPPER(@thisAction) = 'DENIED'
		BEGIN
			IF @woStatus = 'DENIED' OR @woStatus = 'CANCELED' OR @woStatus = 'CLOSED'
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order cannot be DENIED because the status is: ' + @woStatus	
			ELSE
			BEGIN
				UPDATE WO SET IsOpen = 0, Status = 'DENIED', StatusDesc = 'Denied', StatusDate = @currDate, 
					RowVersionUserPK = NULL, RowVersionInitials = '_MC', RowVersionAction = 'STATUS', RowVersionDate = @currDate 
					WHERE (WOPK = @WOPK) OR
					(WOGroupPK IN (SELECT WOGroupPK FROM WO WITH (NOLOCK) WHERE (WOPK = @WOPK) AND WOGroupPK > 0 AND WOGroupType = 'M')) AND WO.PDAWO = 0 
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order successfully marked as Denied'
			END
		END
		ELSE IF UPPER(@thisAction) = 'CANCELED'
		BEGIN
			IF @woStatus = 'DENIED' OR @woStatus = 'CANCELED' OR @woStatus = 'CLOSED'
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order cannot be CANCELED because the status is: ' + @woStatus	
			ELSE
			BEGIN
				UPDATE WO SET IsOpen = 0, Status = 'CANCELED', StatusDesc = 'Canceled', StatusDate = @currDate, 
					RowVersionUserPK = NULL, RowVersionInitials = '_MC', RowVersionAction = 'STATUS', RowVersionDate = @currDate 
					WHERE (WOPK = @WOPK) OR
					(WOGroupPK IN (SELECT WOGroupPK FROM WO WITH (NOLOCK) WHERE (WOPK = @WOPK) AND WOGroupPK > 0 AND WOGroupType = 'M')) AND WO.PDAWO = 0 
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order successfully marked as Canceled'
			END
		END
		ELSE IF UPPER(@thisAction) = 'ONHOLD'
		BEGIN
			IF @woStatus = 'DENIED' OR @woStatus = 'CANCELED' OR @woStatus = 'CLOSED'
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order cannot be CANCELED because the status is: ' + @woStatus	
			ELSE
			BEGIN
				UPDATE WO SET IsOpen = 1, Status = 'ONHOLD', StatusDesc = 'On-Hold', StatusDate = @currDate, 
					RowVersionUserPK = NULL, RowVersionInitials = '_MC', RowVersionAction = 'STATUS', RowVersionDate = @currDate 
					WHERE (WOPK = @WOPK) OR
					(WOGroupPK IN (SELECT WOGroupPK FROM WO WITH (NOLOCK) WHERE (WOPK = @WOPK) AND WOGroupPK > 0 AND WOGroupType = 'M')) AND WO.PDAWO = 0 
				SELECT @retMessage = @retMessage +' = '+ @WOID +' - Work Order successfully marked as On-Hold'
			END
		END
		ELSE
		BEGIN
			SELECT @retMessage = @retMessage +' = '+'Invalid action: ' + @argAction
		
		END
		
		IF @runSP = 1
		BEGIN
			IF @woIssued IS NULL
				SELECT @woIssued = @currDate, @woIssuedInitials = '_MC'
				
			EXEC MC_CloseWorkOrder @WOPK, @woRequested, @woRequestedInitials, @woIssued, @woIssuedInitials,
				@isResponded, @woResponded, @woRespondedInitials,
				@isCompleted, @woCompleted, @woCompletedInitials, 1,
				@isFinalized, @woFinalized, @woFinalizedInitials,
				@isClosed, @woClosed, @woClosedInitials,			 	
				NULL,3,NULL,NULL,NULL,0,0,-1,NULL,NULL,0,0,NULL,0,0,0,0,
				NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0,0,0,0,'WO','Y',44,'_MC',NULL,NULL,0,0,0,NULL,NULL,0,0
		
			
		END
	END		--  IF @WOPK > 0
	ELSE
	BEGIN
		SELECT @retMessage = @retMessage +' = '+ 'No work order was found in the database for WOID: ' + @WOID
	END
END
ELSE
BEGIN
	SELECT @retMessage = @retMessage +' = '+ 'No work order ID was detected'
END
SELECT @response = @retMessage


GO


