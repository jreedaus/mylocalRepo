
-- only issued and closed are created  see WOPK 50
INSERT INTO [ENT60].[dbo].[WOStatusHistory]
           ([WOPK]
           ,[IsAuthStatus]
           ,[StatusDate]
           ,[Status]
           ,[StatusDesc]
           ,[DemoLaborPK]
           ,[RowVersionIPAddress]
           ,[RowVersionUserPK]
           ,[RowVersionInitials]
           ,[RowVersionDate]
           ,[ApprovalCountCompleted])
     VALUES(
           49			--(<WOPK, int,>
           ,0			--<IsAuthStatus, bit,>
           ,getdate()	--<StatusDate, datetime,>
           ,'ISSUED'		--<Status, varchar(15),>
           ,'Issued'	--<StatusDesc, varchar(50),>
           ,NULL		--<DemoLaborPK, int,>
           ,NULL		--<RowVersionIPAddress, varchar(25),>
           ,NULL		--<RowVersionUserPK, int,>
           ,'_MC'		--<RowVersionInitials, varchar(5),>
           ,getdate()	--<RowVersionDate, datetime,>
           ,0			--<ApprovalCountCompleted, bit,>
           )
GO


