SELECT Asset.AssetPK, WO.*, Asset.ISUP, Asset.IsMeter, Asset.Meter1Reading As A_Meter1Reading, Asset.Meter2Reading As A_Meter2Reading, 
REPLACE(Asset.Photo,'_MAIN','_WO') AS AssetPhoto 
FROM WO WITH (NOLOCK) 
LEFT OUTER JOIN ASSET WITH (NOLOCK) ON ASSET.ASSETPK = WO.ASSETPK 
WHERE WOPK = 62


select * from WO order by 1 desc


SELECT WOPK, WOID, StatusIcon, TargetDate, RowVersionDate FROM WO WHERE FollowupFromWOPK = 62 ORDER BY TargetDate

SELECT WO.WOPK, WO.WOID, WO.TargetDate, WO.RowVersionDate, lts.CodeIcon AS StatusIcon
FROM WO WITH (NOLOCK) INNER JOIN
LookupTableValues lts WITH (NOLOCK) ON WO.Status = lts.CodeName AND lts.LookupTable = 'WOSTATUS'
WHERE FollowupFromWOPK = 62
ORDER BY TargetDate DESC, WOPK DESC