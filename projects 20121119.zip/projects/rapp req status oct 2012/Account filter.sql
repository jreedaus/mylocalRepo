SELECT DISTINCT AccountPK, AccountID, AccountName 
FROM WO WITH (NOLOCK)  WHERE 1=1 AND (WO.Requested > CONVERT(Char(10),DateAdd(d,-360,getDate()),112) or WO.IsOpen = 1)z 
 AND AccountPK IS NOT NULL ORDER BY AccountName ASC
 
SELECT DISTINCT AccountPK, AccountID, AccountName 
FROM WO WITH (NOLOCK)  WHERE 1=1 AND (WO.Requested > CONVERT(Char(10),DateAdd(d,-360,getDate()),112) or WO.IsOpen = 1)  
 AND AccountPK IS NOT NULL AND RepairCenterPK IN (1) ORDER BY AccountName ASC
 
 SELECT DISTINCT CategoryPK, CategoryID, CategoryName FROM WO WITH (NOLOCK)
 
SELECT DISTINCT CategoryPK, CategoryID, CategoryName 
FROM WO WITH (NOLOCK)  WHERE 1=1 AND (WO.Requested > CONVERT(Char(10),DateAdd(d,-360,getDate()),112) or WO.IsOpen = 1)  
 AND CategoryPK > 0
