SELECT     WOlabor.*, lt.moduleid, Labor.Photo, WAS.Completed
FROM         WOlabor WITH (NOLOCK)  LEFT OUTER JOIN WOAssignStatus WAS WITH (NOLOCK) ON WAS.WOPK = WOlabor.WOPK AND WAS.LaborPK = WOlabor.LaborPK
                      LEFT OUTER JOIN Labor WITH (NOLOCK) ON WOlabor.LaborPK = Labor.LaborPK INNER JOIN
                      LaborTypes lt WITH (NOLOCK) ON lt.LaborType = Labor.LaborType
WHERE     (WOlabor.WOPK = 69) AND (WOlabor.RecordType = 2)
ORDER BY WOlabor.LaborType, WOlabor.WorkDate, WOlabor.LaborName