select * from WO order by 1 desc

select * from WOPart order by 1 desc

select * from WOMiscCost order by 1 desc

select EstimatePK, * from WOLabor order by 2 desc
--  set the estimatepk of a recordtype 2 so it will show green
-- update wolabor set estimatepk = 32 where pk = 36
SELECT * FROM LABOR