select * from part

Select * from partvendor

select * from partlocation

select * from location
select * from wo order by 1 desc
select * from wopart order by 1 desc
select * from womisccost order by 1 desc
select * from wolabor order by 1 desc

delete wopart where pk = 13
--	update wopart set  quantityactual = 3 where pk = 19

select reportfile, * from reports 
where reportid like 'work%' 
or reportfile like 'rpt_check%'
order by reportfile