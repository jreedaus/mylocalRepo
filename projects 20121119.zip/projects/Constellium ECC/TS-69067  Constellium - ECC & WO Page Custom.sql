-------------------------------------------------------------
-- This scripts are used to enable use of new customized WO pages
--		workorder\ _workorder_Constellium.asp  
--		workorder\ _workorder_close_Enhanced_Constellium.asp
--		workorder\_workorder_costs_Constellium.htm
--		workorder\ _workorder_close_Enhanced_Data.asp
--		reports\rpt_WO1_nogroups_Constellium_V6.asp
-------------------------------------------------------------
-- Project: TS-69067  Constellium - ECC & WO Page Customization
-- Short Desc: ECC and WO Page customization
-- Developer: John Reed
-- Date: 11/15/2012
-------------------------------------------------------------
-- define the customized files to be used for wo
update MCModule set FormPage = '_workorder_Constellium.asp', 
	ActionPage = '_workorder_Constellium.asp',
	ValidateDir = ' workorder_close_Enhanced_Constellium.asp'
where ModuleID = 'wo'

-- set reports tab to use correct web file
UPDATE Reports SET ReportFile = 'rpt_WO1_nogroups_Constellium_V6.asp' WHERE ReportID = 'WorkOrder'
UPDATE Reports SET ReportFile = 'rpt_WO1_nogroups_Constellium_V6.asp' WHERE ReportID = 'WorkOrderC'
UPDATE Reports SET ReportFile = 'rpt_WO1_nogroups_Constellium_V6.asp' WHERE ReportID = 'WorkOrderNoGroups'
UPDATE Reports SET ReportFile = 'rpt_WO1_nogroups_Constellium_V6.asp' WHERE ReportID = 'WorkOrderCNoGroups'

-- preferences: create the entries for a new preference

IF NOT EXISTS(SELECT PreferenceName FROM Preference WHERE PreferenceName = 'WO_CLOSE_SHOWONDEMAND_FOLLOWUP')
BEGIN
      INSERT INTO Preference 
      (PreferenceName,PreferenceCategory,[Description],DisplayOrder,ShowToRepairCenter,ShowToLabor,DefaultValue,
      DataType,PreferenceHelp,GlobalPreference) 
      VALUES ('WO_CLOSE_SHOWONDEMAND_FOLLOWUP','WO_CLOSE_EN','Show On-Demand Followup WO?',328,1,1,'Yes','B',
      'Setting this preference to yes will display the On-Demand Followup WO on the Complete/Close window.',0)
      INSERT INTO PreferenceModule (PreferenceName,ModuleID) VALUES ('WO_CLOSE_SHOWONDEMAND_FOLLOWUP','WO')
      
      INSERT INTO Preference 
      (PreferenceName,PreferenceCategory,[Description],DisplayOrder,ShowToRepairCenter,ShowToLabor,DefaultValue,
      DataType,PreferenceHelp,GlobalPreference) 
      VALUES ('WO_CLOSE_SHOWONDEMAND_FOLLOWUP_COL','WO_CLOSE_EN','Show On-Demand Followup WO in column 1, 2 or Span both columns?',329,1,1,'1','C',
      'Setting this preference will display the On-Demand Followup WO in the specified column on the Complete/Close window. (Valid entries are 1, 2, SPANTOP, or SPANBOTTOM).',0)
      INSERT INTO PreferenceModule (PreferenceName,ModuleID) VALUES ('WO_CLOSE_SHOWONDEMAND_FOLLOWUP_COL','WO')
      
      INSERT INTO Preference 
      (PreferenceName,PreferenceCategory,[Description],DisplayOrder,ShowToRepairCenter,ShowToLabor,DefaultValue,
      DataType,PreferenceHelp,GlobalPreference) 
      VALUES ('WO_CLOSE_SHOWONDEMAND_FOLLOWUP_SORT','WO_CLOSE_EN','Sort Order for On-Demand Followup WO section',330,1,1,'7','N',
      'Setting this preference will display the On-Demand Followup WO section in the specified order on the Complete/Close window.',0)
      INSERT INTO PreferenceModule (PreferenceName,ModuleID) VALUES ('WO_CLOSE_SHOWONDEMAND_FOLLOWUP_SORT','WO')
END


