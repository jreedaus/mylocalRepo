--select * from woassign
SELECT WOassign.PK, WOassign.WOPK, WOassign.IsAssigned, WOassign.LaborID, WOassign.LaborName, 
Labor.LaborType, WOassign.AssignedHours, WOassign.AssignedDate, 
COALESCE(WOLabor.PK, ActL.EstimatePK) EstimatePK
FROM WOassign WITH (NOLOCK) 
INNER JOIN Labor WITH (NOLOCK) ON Labor.LaborPK = WOassign.LaborPK 
LEFT OUTER JOIN WOLabor WITH (NOLOCK) ON WOAssign.WOlaborPK = WOLabor.EstimatePK
LEFT OUTER JOIN WOLabor ActL WITH (NOLOCK) ON WOAssign.WOlaborPK = ActL.PK
WHERE (WOassign.WOPK in (SELECT WOPK FROM WO WITH (NOLOCK) 
LEFT OUTER JOIN Asset WITH (NOLOCK) ON Asset.AssetPK = WO.AssetPK 
LEFT OUTER JOIN AssetHierarchy WITH (NOLOCK) ON AssetHierarchy.AssetPK = WO.AssetPK 
WHERE WO.WOPK = 69 )) AND (WOassign.Active = 1 or WOassign.Active Is Null) 
ORDER BY WOassign.WOPK, WOassign.IsAssigned Desc, WOassign.LaborName

SELECT WOLabor.EstimatePK, WOlabor.PK, WOlabor.WOPK, WOlabor.LaborPK, lt.moduleid, WOlabor.LaborID, WOlabor.LaborName,
WOlabor.EstimatedHours, WOlabor.RegularHours, WOlabor.OvertimeHours, WOlabor.OtherHours, WOlabor.WorkDate, 
WOlabor.TimeIn, WOlabor.TimeOut, WOlabor.AccountID, WOlabor.AccountName, WOlabor.CategoryID, 
WOlabor.CategoryName, WOlabor.TotalCost, WOlabor.TotalCharge, WOlabor.CostRegular, WOlabor.CostOvertime, 
WOlabor.CostOther, WOlabor.ChargeRate, WOlabor.ChargePercentage, WOlabor.RowVersionDate, Labor.Photo 
FROM WOlabor WITH (NOLOCK) 
INNER JOIN WO WITH (NOLOCK) ON WO.WOPK = WOlabor.WOPK 
LEFT OUTER JOIN Labor WITH (NOLOCK) ON WOlabor.LaborPK = Labor.LaborPK 
INNER JOIN LaborTypes lt WITH (NOLOCK) ON lt.LaborType = Labor.LaborType 
WHERE (WOlabor.RecordType = 2) 
AND (WOlabor.WOPK in (SELECT WOPK FROM WO WITH (NOLOCK) 
LEFT OUTER JOIN Asset WITH (NOLOCK) ON Asset.AssetPK = WO.AssetPK 
LEFT OUTER JOIN AssetHierarchy WITH (NOLOCK) ON AssetHierarchy.AssetPK = WO.AssetPK WHERE WO.WOPK = 69 )) 
ORDER BY WOlabor.WOPK, Labor.LaborName
