SELECT Section = 'Name', ShowIt = ISNULL(Name,0), SortOrder = nameorder FROM RequesterAppOptions WITH (NOLOCK) 
UNION SELECT Section = 'Email', ShowIt = ISNULL(Email,0), SortOrder = emailorder FROM RequesterAppOptions 
UNION SELECT Section = 'Phone', ShowIt = ISNULL(Phone,0), SortOrder = phoneorder FROM RequesterAppOptions 
UNION SELECT Section = 'Account', ShowIt = ISNULL(ShowAccount,0), SortOrder = accountorder FROM RequesterAppOptions 
UNION SELECT Section = 'WOType', ShowIt = ISNULL([Type],0), SortOrder = typeorder FROM RequesterAppOptions 
UNION SELECT Section = 'Priority', ShowIt = ISNULL([Priority],0), SortOrder = priorityorder FROM RequesterAppOptions 
UNION SELECT Section = 'Category', ShowIt = ISNULL(Category,0), SortOrder = categoryorder FROM RequesterAppOptions 
UNION SELECT Section = 'NeededBy', ShowIt = ISNULL(TargetDate,0), SortOrder = neededbyorder FROM RequesterAppOptions 
UNION SELECT Section = 'Department', ShowIt = ISNULL(Department,0), SortOrder = departmentorder FROM RequesterAppOptions 
UNION SELECT Section = 'Asset', ShowIt = ISNULL(Asset,0), SortOrder = assetorder FROM RequesterAppOptions 
UNION SELECT Section = 'Problem', ShowIt = ISNULL(Problem,0), SortOrder = problemorder FROM RequesterAppOptions 
UNION SELECT Section = 'RepairCenter', ShowIt = 1, SortOrder = shoporder FROM RequesterAppOptions
UNION SELECT Section = 'Shop', ShowIt = (CASE WHEN Shop = 1 Then 1 WHEN ShopAll = 1 THEN 1 ELSE 0 END), SortOrder = shoporder FROM RequesterAppOptions 
UNION SELECT Section = 'Task', ShowIt = ISNULL(Task,0), SortOrder = taskorder FROM RequesterAppOptions 
UNION SELECT Section = 'Reason', ShowIt = ISNULL(Reason,0), SortOrder = reasonorder FROM RequesterAppOptions 
UNION SELECT Section = 'Document', ShowIt = ISNULL(ShowDocuments,0), SortOrder = documentorder FROM RequesterAppOptions 
UNION SELECT Section = 'Image', ShowIt = ISNULL(ShowImages,0), SortOrder = imageorder FROM RequesterAppOptions 
UNION SELECT Section = 'MiscFile', ShowIt = ISNULL(ShowMiscFiles,0), SortOrder = miscfileorder FROM RequesterAppOptions 
ORDER BY 3,1

--select * from RequesterAppOptions